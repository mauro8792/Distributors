<?php $__env->startSection('title', 'Sales'); ?>

<?php $__env->startSection('content'); ?>
 <div class="container">
    <div class="row justify-content-center">
       <div class="col-md-11 col-md-offset-8">
            <h2 class="text-white">Ventas del vendedor</h2>
            <table class="table table-responsive">
                <thead class="thead-light">
                    <th scope="col">Empleado</th>
                    <th scope="col">Linea</th>
                    <th scope="col">Kgs.</th>
                    <th scope="col" width="2%">
                        <?php if(Auth::user()->hasRole('user')): ?>
                            
                            <a href="/ventas/selectLine" class="btn btn-success btn-sm">Nueva</a>
                        <?php endif; ?>
                    </th>
                </thead>
                <tbody class="text-white">
                    <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><a href="/ventas/saleForEmployee/<?php echo e($venta->name); ?>" class="btn btn-success btn-sm"><?php echo e($venta->name); ?></a></td>
                            <td><?php echo e($venta->slug); ?></td>
                            <td><?php echo e($venta->ventas); ?></td>
                            <td class="text-center"><button type="submit" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#modalDelete<?php echo e($venta->id); ?>" title="Eliminar"><i class="fa fa-trash-o"></i></button>                               
                        </tr>
                                                     
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            
          
        </div>   
    </div>
</div>     

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>