@extends('layouts.app')
    @section('content')
        <div class="container">
            <h1>This action is unauthorized</h1>
        </div>
    @endsection