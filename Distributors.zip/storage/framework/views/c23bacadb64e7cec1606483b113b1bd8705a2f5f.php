<?php $__env->startSection('title', 'Edit distributor'); ?>

<?php $__env->startSection('content'); ?>
    <p>Distributor: </p>
<form class="form-group" method="POST" action="/distributors/<?php echo e($distributor->slug); ?>">
        <?php echo method_field('put'); ?>
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="">Name</label>
            <input type="text" name="name" class="form-control" value="<?php echo e($distributor->name); ?>">
        </div>
        
        <div class="form-group">
            <label for="">Telephone</label>
            <input type="text" name="telephone" class="form-control" value="<?php echo e($distributor->telephone); ?>">
        </div>

        <div class="form-group">
            <label for="">Address</label>
            <input type="text" name="address" class="form-control" value="<?php echo e($distributor->address); ?>">
        </div>
        
        

        
        <button type="submit" class="btn btn-primary">Guardar</button>
    </form> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>