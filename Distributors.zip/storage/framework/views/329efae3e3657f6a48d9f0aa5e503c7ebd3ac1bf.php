<?php $__env->startSection('title', 'Create Commerce'); ?>

<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <p>New Commerce: </p>
    <form class="form-group" method="POST" action="/commerces">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="">Name</label>
            <input type="text" name="name" class="form-control">
        </div>
        
        <div class="form-group">
            <label for="">Telephone</label>
            <input type="text" name="telephone" class="form-control">
        </div>

        <div class="form-group">
            <label for="">Address</label>
            <input type="text" name="address" class="form-control">
        </div>
        
        <div class="form-goup">
            <label for="">Select to Distributor</label>
            <?php $__currentLoopData = $dist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <select name="distributor">
                    <option value="<?php echo e($dis->id); ?>"><?php echo e($dis->name); ?></option>
                </select>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
        </div>

        
        <button type="submit" class="btn btn-primary">Guardar</button>
    </form> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>