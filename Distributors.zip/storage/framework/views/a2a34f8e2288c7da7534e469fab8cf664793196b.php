<?php $__env->startSection('title', 'Create Sales'); ?>

<?php $__env->startSection('content'); ?>
 <div class="container">
    <div class="row justify-content-center">
       <div class="col-md-6 col-md-offset-8">
            <?php if($errors->any()): ?>
                <div class="alert alert danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <form class="form-group" method="POST" action="/sales">
                <h2 class="text-white">Nueva Venta: </h2>                 
                <?php echo csrf_field(); ?>
                <div class="form-row">
                   <div class="col-md-12 mb-4">
                        <label for="employee_id" class="text-white">Empleado</label>
                        <input type="text" name="employee_id" id="employee_id" class="form-control input-lg text-success" value="<?php echo e($employee->name); ?>" disabled >
                        <input type="hidden"  name="employee_id" value="<?php echo e($employee->id); ?>">
                    </div>
                </div>   
                <div class="form-row">
                    <div class="col-md-8 mb-4">
                        <label for="products" class="control-label text-white">Select to Line</label>
                           <select class="form-control text-success" name="product_id" id="product_id" disabled>
                               <option value="<?php echo e($products->id); ?>" class="form-control input-lg text-success" ><?php echo e($products->name); ?></option>
                               <input type="hidden"  name="product_id" value="<?php echo e($products->id); ?>">
                            </select>
                    </div>
                    <div class="col-md-2 mb-4">
                        <label for="kilograms" class="control-label text-white">Kilogramos</label>
                            <select class="form-control text-success" name="kilograms" id="kilograms">
                            <?php $__currentLoopData = $products->kilograms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kilos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kilos->kilogram); ?>"><?php echo e($kilos->kilogram); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             
                            
                        </select>
                    </div>
                 
                    <div class="col-md-2 mb-4">
                        <label for="amount" class="text-white">Cantidad</label>
                        <input type="text" name="amount" id="amount" class="form-control input-lg text-success">
                    </div>     
                       
                </div>
                <div class="form-group text-center">     
                    <input type="hidden"  name="date" value="<?php echo e(now()); ?>">           
                    <button type="submit" class="btn btn-success">Guardar</button>
                </div>
            </form> 
        </div>              
    </div>  
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>