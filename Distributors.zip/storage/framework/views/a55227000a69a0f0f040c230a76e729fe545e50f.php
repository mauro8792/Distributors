<?php $__env->startSection('title', 'Create Products'); ?>

<?php $__env->startSection('content'); ?>
 <div class="container">
    <div class="row justify-content-center">
       <div class="col-md-8 col-md-offset-8">
            <?php if($errors->any()): ?>
                <div class="alert alert danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <form class="form-group" method="POST" action="/products/<?php echo e($product->slug); ?>">
                <h2 class="text-white">Editar Linea: </h2>                
                <?php echo method_field('put'); ?>
                <?php echo csrf_field(); ?>
                <div class="form-row">
                    <div class="col-md-6 mb-4">
                        <label for="name" class="text-white">Nombre</label>
                        <input type="text" name="name" id="name" class="form-control input-lg text-success" value="<?php echo e($product->name); ?>">
                    </div>
        
                    <div class="col-md-6 mb-4">
                        <label for="distributor" class="text-white">Seleccione Distribuidor</label>
                            <select class="form-control text-success" name="distributor" id="distributor">
                                <?php $__currentLoopData = $dist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dis->id); ?>" <?php echo e(($dis->id==$product->distributor_id)?"selected":""); ?>><?php echo e($dis->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    </div>


                </div>

                <div class="form-row">
                    <div class="col-md-12 mb-4">
                        <label for="distributor" class="text-white">Seleccione Kilogramos</label>
                            <div class="input-group-prepend">

                               <?php $__currentLoopData = $kilograms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="input-group-text col-md-1 m-2"> 
                                    <input type="checkbox" name="kgs[]" value="<?php echo e($k->id); ?>"
                                        <?php for($i = 0; $i <sizeOf( $product->kilograms); $i++): ?>
                                            <?php if($product->kilograms[$i]->id== $k->id): ?>
                                                checked
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                    >
                                    <?php echo e($k->kilogram); ?>

                                 </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </div>
                    </div>
                </div>

                <div class="form-group text-center">                
                    <button type="submit" class="btn btn-success">Guardar</button>
                </div>
            </form> 
        </div>              
    </div>  
</div>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>