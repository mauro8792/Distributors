<?php $__env->startSection('title', 'Edit commerce'); ?>

<?php $__env->startSection('content'); ?>
 <div class="container">
    <div class="row justify-content-center">
       <div class="col-md-10 col-md-offset-8">
            <form class="form-group" method="POST" action="/commerces/<?php echo e($commerce->slug); ?>">
                <h2 class="text-white">Editar Comercio: </h2>            
                <?php echo method_field('put'); ?>
                <?php echo csrf_field(); ?>
                <div class="form-row">                  
                    <div class="col-md-6 mb-4">
                        <label for="name" class="text-white">Nombre</label>
                        <input type="text" name="name" id="name" class="form-control input-lg text-success" value="<?php echo e($commerce->name); ?>">
                    </div>
                    
                    <div class="col-md-6 mb-4">
                        <label for="telephone" class="text-white">Telefono</label>
                        <input type="text" name="telephone" id="telephone" class="form-control input-lg text-success" value="<?php echo e($commerce->telephone); ?>">
                    </div>
                </div>
                <div class="form-row">  
                    <div class="col-md-6 mb-4">
                        <label for="address" class="text-white">Domicilio</label>
                        <input type="text" name="address" id="address" class="form-control input-lg text-success" value="<?php echo e($commerce->address); ?>">
                    </div>
                    <div class="col-md-6 mb-4">
                        <label for="distributor" class="text-white">Seleccione Distribuidor</label>
                           <select class="form-control text-success" name="distributor" id="distributor">
                                <?php $__currentLoopData = $dist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dis->id); ?>" <?php echo e(($dis->id==$commerce->distributor_id)?"selected":""); ?>><?php echo e($dis->name); ?></option>                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    </div>
                </div>
                <div class="form-row">
                     <div class="col-md-6 mb-4">
                        <label for="address" class="t_blanco">Numero de Cliente</label>
                        <input type="number" name="numberOfClient" id="numberOfClient" class="form-control input-lg text-success" value="<?php echo e($commerce->numberOfClient); ?>">
                    </div>
                    
                </div>
                <div class="form-group text-center">                
                    <button type="submit" class="btn btn-success">Guardar</button>
                </div>
            </form> 
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>