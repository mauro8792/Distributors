 
<?php $__env->startSection('title', 'Employees'); ?>

<?php $__env->startSection('content'); ?>
 <div class="container">
    <div class="row justify-content-center">
       <div class="col-md-12 col-md-offset-8">
            <h2 class="t_blanco">Listado de Empleados</h2>
            <table class="table table-responsive">
                <thead class="thead-light">
                    <th scope="col"><a href="/empleados/<?php echo e($orden); ?>" class="text-success" style="text-decoration:none" data-toggle="tooltip" title="Orden <?php echo e($orden); ?>">Nombre&nbsp;<i class="fa fa-arrow-<?php echo e(($orden=='asc')?'up':'down'); ?>"></i></a></th>
                    <th scope="col">Telefono</th>
                    <th scope="col">Dni</th>
                    <th scope="col">Email</th>
                    <th scope="col">Comercio</th>
                    <th scope="col" width="4%"><a href="/empleados/nuevo" class="btn btn-success btn-sm">Nuevo</a></th>
                    <th scope="col" width="4%"></th>
                </thead>
                <tbody class="t_blanco">
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($empleado->lastname); ?>, <?php echo e($empleado->name); ?></td>
                            <td><?php echo e($empleado->telephone); ?></td>
                            <td><?php echo e($empleado->dni); ?></td>
                            <td><?php echo e($empleado->email); ?></td>
                            <td>
                                <?php $__currentLoopData = $commerces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Commerce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <?php if($empleado->commerce->id==$Commerce->id): ?>
                                        <?php echo e($Commerce->name); ?>

                                    <?php endif; ?>      
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
                            </td>
                            <!-- Modal -->
                            <div class="modal fade" id="modalDelete<?php echo e($empleado->slug); ?>" tabindex="-1" role="dialog" aria-labelledby="modalDeleteLabel" aria-hidden="true">
                              <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                  <div class="modal-header bg-danger">
                                    <h5 class="modal-title t_blanco" id="modalDeleteLabel">Eliminar</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                  </div>
                                  <div class="modal-body">
                                    <p>Desea eliminar el registro <strong><?php echo e($empleado->name); ?> <?php echo e($empleado->lastname); ?></strong></p>
                                  </div>
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <form method="POST" action="/employees/<?php echo e($empleado->slug); ?>">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>

                                        <button type="submit" class="btn btn-danger">Eliminar</button>
                                    </form>            
                                  </div>
                                </div>
                              </div>
                            </div>     
                            <!-- End Modal -->                             
                            <td><a href="/employees/<?php echo e($empleado->slug); ?>/edit" class="btn btn-success btn-sm">&nbsp;Editar&nbsp;</a> </td>
                            <td><button type="submit" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#modalDelete<?php echo e($empleado->slug); ?>">Eliminar</button>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>   
    </div>
</div>  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>