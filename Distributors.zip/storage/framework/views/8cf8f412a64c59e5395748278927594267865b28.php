<?php $__env->startSection('title', 'Distributors'); ?>

<?php $__env->startSection('content'); ?>
    <p>List of Distributors</p>

    <table class="table">
        <thead>
            <th scope="col">Name  </th>
            <th scope="col">Telephone</th>
            <th scope="col">Address</th>
            <th scope="col">Edit</th>
            <th scope="col">Eliminar</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $dist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($dis->name); ?></th>
                    <td > <?php echo e($dis->telephone); ?></td>
                    <td><?php echo e($dis->address); ?></td>
                    <!-- <td><a href="/distributors/<?php echo e($dis->slug); ?>" class="btn btn-primary">Ver más..</a> </td> -->
                    <td><a href="/distributors/<?php echo e($dis->slug); ?>/edit" class="btn btn-primary">Editar..</a> </td>
                    <td> <form method="POST" action="/distributors/<?php echo e($dis->slug); ?>">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                     <button type="submit" class="btn btn-danger">Eliminar</button> </form>
                </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>