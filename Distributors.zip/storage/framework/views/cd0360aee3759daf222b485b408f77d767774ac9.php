<?php $__env->startSection('title', 'Products'); ?>

<?php $__env->startSection('content'); ?>
 <div class="container">
    <div class="row justify-content-center">
       <div class="col-md-10 col-md-offset-8">
            <h2 class="t_blanco">Listado de Lineas</h2>
            <table class="table table-responsive">
                <thead class="thead-light">
                    <th scope="col">Nombre</th>
                    <th scope="col">Distribuidor</th>
                    <th scope="col" width="2%" colspan="2"><a href="/productos/nuevo" class="btn btn-success btn-sm">Nuevo</a></th>
                </thead>
                <tbody class="t_blanco">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($prod->name); ?></td>
                            <td>
                               <?php echo e($prod->distributor->name); ?>              
                            </td>
                            
                            <td><a href="/products/<?php echo e($prod->slug); ?>/edit" class="btn btn-success" title="Editar"><i class="fa fa-pencil-square-o"></i></a></td>
                            <td><button type="submit" class="btn btn-danger" data-toggle="modal" data-target="#modalDelete<?php echo e($prod->id); ?>" title="Eliminar"><i class="fa fa-trash-o"></i></button>
                        </tr>
                            <!-- Modal -->
                            <div class="modal fade" id="modalDelete<?php echo e($prod->id); ?>" tabindex="-1" role="dialog" aria-labelledby="modalDeleteLabel" aria-hidden="true">
                              <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                  <div class="modal-header bg-danger">
                                    <h5 class="modal-title t_blanco" id="modalDeleteLabel">Eliminar</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                  </div>
                                  <div class="modal-body">
                                    <p>Desea eliminar el registro <strong><?php echo e($prod->name); ?></strong></p>
                                  </div>
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <form method="POST" action="/products/<?php echo e($prod->slug); ?>">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>

                                        <button type="submit" class="btn btn-danger">Eliminar</button>
                                    </form>            
                                  </div>
                                </div>
                              </div>
                            </div>     
                            <!-- End Modal -->                          
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>   
    </div>
</div>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>