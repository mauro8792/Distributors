<?php $__env->startSection('title', 'Sales'); ?>

<?php $__env->startSection('content'); ?>
 <div class="container">
    <div class="row justify-content-center">
       <div class="col-md-11 col-md-offset-8">
            <?php if(Auth::user()->hasRole('admin')): ?>
                <form method="POST" action="/ventas/employeeBestSale" class="form-inline">
                  <?php echo csrf_field(); ?>
                <div class="col-lg-5">
                    <div class="input-group mb-4">
                        <div class="input-group-prepend">
                             <label class="input-group-text bg-success text-white" for="inicial">Mes</label>
                        </div>
                        <input class="input-group-text bg-success text-white" type="month" name="mes" id="mes" value="2019-10">  
                        <input class="btn btn-success" type="submit" name="enviar" value="Buscar">    
                    </div>
                </div>
                </form>
            <?php endif; ?>
            <h2 class="text-white">Listado de Ventas</h2>
            <table class="table table-responsive">
                <thead class="thead-light">
                    <th scope="col">Empleado</th>
                    <th scope="col">Linea</th>
                    <th scope="col">Kgs.</th>
                    <th scope="col">Cant.</th>
                    <th scope="col">Fecha</th>
                    <th scope="col" width="2%">
                        <?php if(Auth::user()->hasRole('user')): ?>
                            
                            <a href="/ventas/selectLine" class="btn btn-success btn-sm">Nueva</a>
                        <?php endif; ?>
                    </th>
                </thead>
                <tbody class="text-white">
                    <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($venta->employee->lastname); ?>, <?php echo e($venta->employee->name); ?></td>
                            <td><?php echo e($venta->product->name); ?></td>
                            <td><?php echo e($venta->kilograms); ?></td>
                            <td><?php echo e($venta->amount); ?></td>
                            <td><?php echo e($venta->created_at->format('d-m-Y')); ?></td>
                            <td class="text-center"><button type="submit" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#modalDelete<?php echo e($venta->id); ?>" title="Eliminar"><i class="fa fa-trash-o"></i></button>                               
                        </tr>
                            <!-- Modal -->
                            <div class="modal fade" id="modalDelete<?php echo e($venta->id); ?>" tabindex="-1" role="dialog" aria-labelledby="modalDeleteLabel" aria-hidden="true">
                              <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                  <div class="modal-header bg-danger">
                                    <h5 class="modal-title text-white" id="modalDeleteLabel">Eliminar</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                  </div>
                                  <div class="modal-body">
                                    <p>Desea eliminar el registro <strong><?php echo e($venta->employee->lastname); ?>, <?php echo e($venta->employee->name); ?> <?php echo e($venta->product->name); ?> <?php echo e($venta->date); ?></strong></p>
                                  </div>
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <form method="POST" action="/sales/<?php echo e($venta->slug); ?>">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>

                                        <button type="submit" class="btn btn-danger">Eliminar</button>
                                    </form>            
                                  </div>
                                </div>
                              </div>
                            </div>     
                            <!-- End Modal -->                          
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php if(Auth::user()->hasRole('admin')): ?>            
            <a href="/ventas/employeeBestSale" class="btn btn-success">Quien vendio mas</a>
            <a href="/ventas/employeeBestSaleForLine" class="btn btn-success">Quien vendio mas por linea</a>
        <?php endif; ?>          
        </div>   
    </div>
</div>     

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>