<?php $__env->startSection('title', 'Search Sales'); ?>

<?php $__env->startSection('content'); ?>
 <div class="container">
    <div class="row justify-content-center">
       <div class="col-md-6 col-md-offset-8">
            <?php if($errors->any()): ?>
                <div class="alert alert danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <form class="form-group" method="POST" action="/ventas/searchSale">
                <h2 class="text-white">Ventas por Vendedor: </h2>                 
                <?php echo csrf_field(); ?>
                <div class="form-row">
                    <div class="col-md-12 mb-4">
                        <label for="employee_id" class="control-label text-white">Seleccione Vendedor</label>
                            <select class="form-control text-success" name="employee_id" id="employee_id">
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($employee->id); ?>"><?php echo e($employee->lastname); ?>, <?php echo e($employee->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    </div>
                </div>   
                <div class="form-group text-center">                
                    <button type="submit" class="btn btn-success">Buscar</button>
                </div>
            </form> 
        </div>              
    </div>  
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>