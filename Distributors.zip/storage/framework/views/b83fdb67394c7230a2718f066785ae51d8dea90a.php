<?php $__env->startSection('title', 'Create Employee'); ?>

<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <?php if(Session::has('alert-' . $msg)): ?> 
            <div class="alert alert-danger alert-dismissible">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Cuidado! </strong><?php echo e(Session::get('alert-' . $msg)); ?> ×
            </div>
        <?php endif; ?> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <div class="container">
    <div class="row justify-content-center">
       <div class="col-md-10 col-md-offset-8">
            <?php if($errors->any()): ?>
                <div class="alert alert danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form class="form-group" method="POST" action="/employees">
                <h2 class="t_blanco">Nuevo Empleado: </h2>
                <?php echo csrf_field(); ?>
                <div class="form-row">
                    <div class="col-md-4 mb-4">
                        <label for="name" class="t_blanco">Nombre</label>
                        <input type="text" name="name" id="name" class="form-control input-lg text-success" value="<?php echo e($usuario->name); ?>" disabled >
                        <input type="hidden"  name="name1" value="<?php echo e($usuario->name); ?>">
                        <input type="hidden"  name="user_id" value="<?php echo e($usuario->id); ?>">
                    </div>
                    <div class="col-md-4 mb-4">
                        <label for="lastname" class="t_blanco">Apellido</label>
                        <input type="text" name="lastname" id="lastname" class="form-control input-lg text-success" value="<?php echo e($usuario->lastname); ?>" disabled >
                        <input type="hidden"  name="lastname1" value="<?php echo e($usuario->lastname); ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="email" class="t_blanco">Email</label>
                        <input type="email" name="email" id="email" class="form-control input-lg text-success" value="<?php echo e($usuario->email); ?>" disabled>
                        <input type="hidden"  name="email1" value="<?php echo e($usuario->email); ?>">
                    </div>                    
                </div>
                <div class="form-row">            
                    <div class="col-md-4 mb-3">
                        <label for="telephone" class="t_blanco">Teléfono</label>
                        <input type="text" name="telephone" id="telephone" class="form-control input-lg text-success">
                    </div>                
                    <div class="col-md-4 mb-3">
                        <label for="dni" class="t_blanco">Dni</label>
                        <input type="text" name="dni" id="dni" class="form-control input-lg text-success">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="numberOfClient" class="control-label t_blanco">Numero de Comercio</label>
                        <input type="number" name="numberOfClient" id="numberOfClient" class="form-control input-lg text-success">
                       
                    </div>  
                </div>
                <div class="form-group text-center">                
                    <button type="submit" class="btn btn-success">Guardar</button>
                </div>
            </form> 
        </div>              
    </div>  
</div>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>