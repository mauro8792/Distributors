<?php $__env->startSection('title', 'Commerces'); ?>

<?php $__env->startSection('content'); ?>
    <p>List of Commerces</p>

    <table class="table">
        <thead>
            <th scope="col">Name  </th>
            <th scope="col">Telephone</th>
            <th scope="col">Address</th>
            <th scope="col">Edit</th>
            <th scope="col">Eliminar</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $comercio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($com->name); ?></th>
                    <td > <?php echo e($com->telephone); ?></td>
                    <td><?php echo e($com->address); ?></td>
                    <!-- <td><a href="/distributors/<?php echo e($com->slug); ?>" class="btn btn-primary">Ver más..</a> </td> -->
                    <td><a href="/distributors/<?php echo e($com->slug); ?>/edit" class="btn btn-primary">Editar..</a> </td>
                    <td> <form method="POST" action="/distributors/<?php echo e($com->slug); ?>">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                     <button type="submit" class="btn btn-danger">Eliminar</button> </form>
                </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>