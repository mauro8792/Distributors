<?php $__env->startSection('title', 'Edit Employee'); ?>

<?php $__env->startSection('content'); ?>
 <div class="container">
    <div class="row justify-content-center">
       <div class="col-md-10 col-md-offset-8">
            <form class="form-group" method="POST" action="/employees/<?php echo e($employee->slug); ?>">
                <h2 class="t_blanco">Editar Empleado: </h2>                
                    <?php echo method_field('put'); ?>
                    <?php echo csrf_field(); ?>
                <div class="form-row">                    
                    <div class="col-md-4 mb-4">
                        <label for="name" class="t_blanco">Nombre</label>
                        <input type="text" name="name" id="name" class="form-control input-lg text-success" value="<?php echo e($employee->name); ?>">
                    </div>
                    <div class="col-md-4 mb-4">
                        <label for="lastname" class="t_blanco">Apellido</label>
                        <input type="text" name="lastname" id="lastname" class="form-control input-lg text-success" value="<?php echo e($employee->lastname); ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="email" class="t_blanco">Email</label>
                        <input type="email" name="email" id="email" class="form-control input-lg text-success" value="<?php echo e($employee->email); ?>">
                    </div>
                </div>
                <div class="form-row">    
                    <div class="col-md-4 mb-3">
                        <label for="telephone" class="t_blanco">Telefono</label>
                        <input type="text" name="telephone" id="telephone" class="form-control input-lg text-success" value="<?php echo e($employee->telephone); ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="dni" class="t_blanco">Dni</label>
                        <input type="text" name="dni" id="dni" class="form-control input-lg text-success" value="<?php echo e($employee->dni); ?>">
                    </div>               
                    <div class="col-md-4 mb-4">
                        <label for="commerce" class="control-label t_blanco">Seleccione Comercio</label>
                           <select class="form-control text-success" name="commerce" id="commerce">
                               <?php $__currentLoopData = $commerce; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($com->id); ?>" class="form-control input-lg text-success"><?php echo e($com->name); ?> - <?php echo e($com->numberOfClient); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    </div>
                </div>
                <div class="form-group text-center">                
                    <button type="submit" class="btn btn-success">Guardar</button>
                </div>
                </form> 
        </div>              
    </div>  
</div>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>