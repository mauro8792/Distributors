<?php $__env->startSection('title', 'Create Sales'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card-deck text-center">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a class="btn btn-outline-success btn-lg m-2"  href="/ventas/kiloForLine/<?php echo e($prod->id); ?> " role="button"><?php echo e($prod->name); ?></a>		
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>