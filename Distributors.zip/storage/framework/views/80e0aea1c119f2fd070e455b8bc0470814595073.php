<?php $__env->startSection('title', 'Team'); ?>
<?php $__env->startSection('content'); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>

    <?php endif; ?>
    <p>Distributor</p>

    <table class="table">
        <thead>
            <th scope="col">Name  </th>
            <th scope="col">Telephone</th>
            <th scope="col">Address</th>
            <th scope="col">eliminar</th>
        </thead>
        <tbody>
            
                <tr>
                    <th scope="row"><?php echo e($distributor->name); ?></th>
                    <td > telefono</td>
                    <td>email</td>
                    <td><a href="/teams/<?php echo e($distributor->slug); ?>/edit" class="btn btn-primary">Editar..</a> </td>
                <td> <form method="POST" action="/teams/<?php echo e($distributor->slug); ?>">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('DELETE')); ?>

                     <button type="submit" class="btn btn-danger">Eliminar</button> </form></td>
                </tr>
            
        </tbody>
    </table>
   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>